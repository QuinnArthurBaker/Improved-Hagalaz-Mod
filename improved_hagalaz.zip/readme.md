# About

This is a simple mod made for The Binding Of Isaac: Afterbirth+. You can check it out and install it on the mod's Steam Workshop page [here](https://steamcommunity.com/sharedfiles/filedetails/?id=1689683831)
